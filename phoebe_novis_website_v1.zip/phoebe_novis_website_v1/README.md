# PHOEBE NOVIS Website V1.0

A single-page responsive concept website for:
PHOEBE NOVIS
Global Fashion Supply Chain & Brand Growth

Open index.html in a browser to preview.

Next iteration ideas:
- Replace the abstract hero with final brand photography / 3D visual.
- Add actual email, social links and contact form.
- Add dedicated pages for Services, Portfolio and océvelle.
- Connect a CMS or hosting platform when ready.
